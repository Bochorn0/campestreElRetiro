export const environment = {  
  apiUrl: 'http://134.209.238.227:3000',
  debugMode: true
};